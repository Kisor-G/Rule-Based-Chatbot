import json
import pickle
import random
import numpy as np
import nltk
from nltk.stem import WordNetLemmatizer
from sklearn.utils.class_weight import compute_class_weight
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout

# Initialize lemmatizer
lemmatizer = WordNetLemmatizer()

# Define intents data
intents = {
    "intents": [
        {
            "tag": "greeting",
            "patterns": [
                "Hi", "Hey", "Hello", "Good morning", "Good afternoon",
                "Good evening", "Is anyone there?", "Hi there"
            ],
            "responses": [
                "Om Namah Shivaya! Welcome to Amrita Vishwa Vidyapeetham, guided by our Chancellor AMMA. We're here to help you with information about our programs, campuses, and admissions."
            ]
        },
        {
            "tag": "goodbye",
            "patterns": [
                "bye", "see you later", "goodbye", "thanks bye", "thank you bye",
                "thats all", "see you", "exit", "quit"
            ],
            "responses": [
                "Thank you for connecting with Amrita Vishwa Vidyapeetham. We're here whenever you need more information. Have a great day!"
            ]
        },
        {
            "tag": "admission_criteria",
            "patterns": [
                "What are the admission criteria?", "How can I get admission?",
                "Tell me about admission process", "What are the requirements for admission?",
                "How to apply?", "Admission requirements", "Entry requirements"
            ],
            "responses": [
                "For admission to Amrita Vishwa Vidyapeetham, you need:\n- Valid entrance exam scores (JEE/NEET/AEEE as applicable)\n- Minimum 60% in 12th grade\n- Completion of online application\nFor detailed criteria, visit our admissions portal."
            ]
        },
        {
            "tag": "location",
            "patterns": [
                "Where is the campus?", "Campus location", "Where are you located?",
                "College address", "How to reach campus", "Directions to college"
            ],
            "responses": [
                "Amrita Vishwa Vidyapeetham has nine campuses across India:\n- Coimbatore (Main Campus)\n- Amritapuri\n- Bengaluru\n- Chennai\n- Cochin\n- Amaravati\n- Faridabad\n- Mysuru\n- Nagercoil\nFor specific campus directions, please visit our website."
            ]
        },
        {
            "tag": "courses",
            "patterns": [
                "What courses are offered?", "Available programs", "List of courses",
                "What can I study?", "Programs offered", "Degree programs",
                "Tell me about courses"
            ],
            "responses": [
                "Amrita offers 250+ programs including:\n- Engineering (B.Tech/B.E)\n- Medical Sciences (MBBS, BDS)\n- Management Studies (BBA, MBA)\n- Science Programs (B.Sc, M.Sc)\n- Arts & Humanities\n- Research Programs (Ph.D)\nFor detailed course information, please specify your area of interest."
            ]
        },
        {
            "tag": "unknown",
            "patterns": [],
            "responses": [
                "I apologize, but I'm not sure I understand your question. Could you please rephrase it or select from these topics:\n1. Admission Process\n2. Campus Locations\n3. Available Courses\n4. Fee Structure"
            ]
        }
    ]
}

# Initialize lists
words = []
classes = []
documents = []
ignore_chars = ['?', '!', ',', '.']

# Process patterns and create training data
for intent in intents['intents']:
    for pattern in intent['patterns']:
        # Tokenize words
        word_list = nltk.word_tokenize(pattern)
        words.extend(word_list)
        documents.append((word_list, intent['tag']))
        if intent['tag'] not in classes:
            classes.append(intent['tag'])

# Lemmatize and clean words
words = [lemmatizer.lemmatize(word.lower()) for word in words if word not in ignore_chars]
words = sorted(list(set(words)))
classes = sorted(list(set(classes)))

# Create training data
training = []
output_empty = [0] * len(classes)

for doc in documents:
    bag = []
    pattern_words = doc[0]
    pattern_words = [lemmatizer.lemmatize(word.lower()) for word in pattern_words]

    for word in words:
        bag.append(1) if word in pattern_words else bag.append(0)

    output_row = list(output_empty)
    output_row[classes.index(doc[1])] = 1
    training.append([bag, output_row])

# Shuffle and prepare training data
random.shuffle(training)
training = np.array(training, dtype="object")
train_x = list(training[:, 0])
train_y = list(training[:, 1])

# Build model
model = Sequential()
model.add(Dense(128, input_shape=(len(train_x[0]),), activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(64, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(len(train_y[0]), activation='softmax'))

# Compile model
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# Train model
hist = model.fit(np.array(train_x), np.array(train_y), epochs=200, batch_size=5, verbose=1)

# Save model and words/classes
model.save("chatbot_model.h5")
pickle.dump(words, open("words.pkl", "wb"))
pickle.dump(classes, open("classes.pkl", "wb"))
