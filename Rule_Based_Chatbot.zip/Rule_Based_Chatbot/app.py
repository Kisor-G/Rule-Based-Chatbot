from flask import Flask, render_template, request, jsonify
import csv
import ast

app = Flask(__name__)

# Load intents from CSV
def load_intents(file_path):
    intents = []
    with open(file_path, 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        for row in reader:
            patterns = ast.literal_eval(row['patterns'])
            responses = row['responses']
            intents.append({"tag": row['tag'], "patterns": patterns, "responses": responses})
    return intents

# Chatbot logic
def get_response(intents, user_message):
    user_message = user_message.lower()
    for intent in intents:
        for pattern in intent["patterns"]:
            if pattern.lower() in user_message:
                return intent["responses"]
    return "I'm sorry, I didn't understand that. Can you please rephrase?"

# Load intents
intents = load_intents('chatbot_intents.csv')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get', methods=['POST'])
def chatbot_response():
    user_message = request.json.get('message')
    response = get_response(intents, user_message)
    return jsonify({"response": response})

if __name__ == '__main__':
    app.run(debug=True)
